
#!/usr/bin/env bash
set -euo pipefail
aws ecr get-login-password --region "${AWS_REGION}" | docker login --username AWS --password-stdin "$(aws sts get-caller-identity --query Account --output text)".dkr.ecr."${AWS_REGION}".amazonaws.com
