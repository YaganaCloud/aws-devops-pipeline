
#!/usr/bin/env bash
# Usage: deploy.sh <IMAGE_URI> <AWS_REGION>
set -euo pipefail
IMAGE_URI="$1"
AWS_REGION="$2"

aws eks update-kubeconfig --name devops-cluster --region "${AWS_REGION}"

tmpfile=$(mktemp)
sed "s#REPLACE_WITH_ECR_URI#${IMAGE_URI%:*}#g" k8s/deployment.yaml > "$tmpfile"

kubectl apply -f "$tmpfile"
kubectl apply -f k8s/service.yaml
kubectl apply -f k8s/hpa.yaml

echo "Waiting for rollout..."
kubectl rollout status deployment/myapp-deployment
kubectl get svc myapp-service -o wide
